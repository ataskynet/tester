@extends('admin')

@section('content')
    <div class="wrapper wrapper-content animated fadeInUp">
        @include('inspina.notice.partials.board')  
        @include('inspina.notice.partials.pin')
    </div>
@endsection