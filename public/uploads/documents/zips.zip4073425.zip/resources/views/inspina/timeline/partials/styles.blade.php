<link href="http://localhost:8000/inspina/css/plugins/chosen/chosen.css" rel="stylesheet">
    <link href="http://localhost:8000/inspina/css/plugins/iCheck/custom.css" rel="stylesheet">

    <link href="http://localhost:8000/inspina/css/plugins/chosen/chosen.css" rel="stylesheet">

    <link href="http://localhost:8000/inspina/css/plugins/colorpicker/bootstrap-colorpicker.min.css" rel="stylesheet">

    <link href="http://localhost:8000/inspina/css/plugins/cropper/cropper.min.css" rel="stylesheet">

    <link href="http://localhost:8000/inspina/css/plugins/switchery/switchery.css" rel="stylesheet">

    <link href="http://localhost:8000/inspina/css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">

    <link href="http://localhost:8000/inspina/css/plugins/nouslider/jquery.nouislider.css" rel="stylesheet">

    <link href="http://localhost:8000/inspina/css/plugins/datapicker/datepicker3.css" rel="stylesheet">

    <link href="http://localhost:8000/inspina/css/plugins/ionRangeSlider/ion.rangeSlider.css" rel="stylesheet">
    <link href="http://localhost:8000/inspina/css/plugins/ionRangeSlider/ion.rangeSlider.skinFlat.css" rel="stylesheet">

