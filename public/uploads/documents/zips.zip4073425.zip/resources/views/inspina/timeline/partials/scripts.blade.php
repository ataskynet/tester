 <!-- Chosen -->
    <script src="http://localhost:8000/inspina/js/plugins/chosen/chosen.jquery.js"></script>

   <!-- JSKnob -->
   <script src="http://localhost:8000/inspina/js/plugins/jsKnob/jquery.knob.js"></script>

   <!-- Input Mask-->
    <script src="http://localhost:8000/inspina/js/plugins/jasny/jasny-bootstrap.min.js"></script>

   <!-- Data pichttp://localhost:8000/inspina/ker -->
   <script src="http://localhost:8000/inspina/js/plugins/datapicker/bootstrap-datepicker.js"></script>

   <!-- NouSlider -->
   <script src="http://localhost:8000/inspina/js/plugins/nouslider/jquery.nouislider.min.js"></script>

   <!-- Switchery -->
   <script src="http://localhost:8000/inspina/js/plugins/switchery/switchery.js"></script>

    <!-- IonRangeSlider -->
    <script src="http://localhost:8000/inspina/js/plugins/ionRangeSlider/ion.rangeSlider.min.js"></script>

    <!-- iCheck -->
    <script src="http://localhost:8000/inspina/js/plugins/iCheck/icheck.min.js"></script>

    <!-- MENU -->
    <script src="http://localhost:8000/inspina/js/plugins/metisMenu/jquery.metisMenu.js"></script>

    <!-- Color picker -->
    <script src="http://localhost:8000/inspina/js/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>

    <!-- Image cropper -->
    <script src="http://localhost:8000/inspina/js/plugins/cropper/cropper.min.js"></script>

    <script>
        $(document).ready(function(){

           
        var config = {
                '.chosen-select'           : {},
                '.chosen-select-deselect'  : {allow_single_deselect:true},
                '.chosen-select-no-single' : {disable_search_threshold:10},
                '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
                '.chosen-select-width'     : {width:"95%"}
            }
            for (var selector in config) {
                $(selector).chosen(config[selector]);
            };

    </script>