<div class="col-md-6">
    <h2 class="font-bold">Welcome to skoolspace</h2>

    <p>
        Perfectly designed and precisely prepared to build community for the school community.
    </p>

    <p>
        1.Individual and bulk messaging services for the school
    </p>

    <p>
        2.Individual profile updates and communication by the school to their clients
    </p>

    <p>
        <small>Those were just a few of the advantages this platform has to offer. Join in the Revolution.</small>
    </p>

</div>