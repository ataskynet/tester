@extends('school')

@section('sidebar')
    @include('partials.client.default_nav')
@stop

@section('content')
    <!-- Dashboard or home view: List of Schools, Number of clients signed on, ... -->
    <h2>Dashboard: Client</h2>

    <!-- End of the Dashboard section -->
    <!-- Partials directory: school.account.partials -->
@stop
