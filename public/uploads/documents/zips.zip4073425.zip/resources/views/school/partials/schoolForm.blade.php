<div class="col-md-9">
    <div class="form-group ">
        <input name="schoolName" type="text" class="form-control" placeholder="Enter the School's Name..">
    </div>
    <div class="form-group">
        <input name="schoolMotto" type="text" class="form-control" placeholder="Enter the School's Motto..">
    </div>
    <div class="form-group">
        <input name="username" type="text" class="form-control" placeholder="Enter the School's unique username..">
    </div>
    <div class="form-group">
        <input name="telNumber" type="text" class="form-control" placeholder="Enter the School's TelephoneNumber..">
    </div>
    <div class="form-group">
        <input name="email" type="text" class="form-control" placeholder="Enter the School's E-mail..">
    </div>
    <div class="form-group">
        <input name="url" type="text" class="form-control" placeholder="Enter the School's Main Site url..">
    </div>

    <div class="form-group">
        <button class="btn btn-primary" type="submit">Create School</button>
    </div>
</div>