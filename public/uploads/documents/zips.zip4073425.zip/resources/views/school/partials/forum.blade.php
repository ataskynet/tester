<div class="chat-room col-md-12" style="margin: 0px">

        <div class="chat-room-head col-md-12" style="background-color: purple; ">
            <h3 style="color: #ffffff">Class Space:</h3>
            <form action="" class="pull-right position">
                <input type="text" placeholder="Search" class="form-control search-btn" style="color: #000000">
            </form>
        </div>
        <div class="group-rom">
            <div class="first-part odd">Sam Soffes</div>
            <div class="second-part">Hi Mark, have a minute?</div>
            <div class="third-part">12:30</div>
        </div>
        <br>
        <div class="group-rom">
            <div class="first-part">Mark Simmons</div>
            <div class="second-part ">Of course Sam, what you need?</div>
            <div class="third-part">12:31</div>
        </div>
        <div class="group-rom">
            <div class="first-part odd">Sam Soffes</div>
            <div class="second-part">I want you examine the new product</div>
            <div class="third-part">12:32</div>
        </div>
        <div class="group-rom">
            <div class="first-part">Mark Simmons</div>
            <div class="second-part">Ok, send me the pic</div>
            <div class="third-part">12:32</div>
        </div>
        <div class="group-rom">
            <div class="first-part odd">Sam Soffes</div>
            <div class="second-part"><a href="#">product.jpg</a> <span class="text-muted">35.4KB</span>
                <p><img class="img-responsive" src="http://localhost:8000/img/product.jpg" alt=""></p></div>
            <div class="third-part">12:32</div>
        </div>
        <div class="group-rom">
            <div class="first-part">Mark Simmons</div>
            <div class="second-part">Fantastic job, love it :)</div>
            <div class="third-part">12:32</div>
        </div>
        <div class="group-rom last-group">
            <div class="first-part odd">Sam Soffes</div>
            <div class="second-part">Thanks!!</div>
            <div class="third-part">12:33</div>
        </div>
        <footer class="col-md-12">
            <form action="" method="post">
                <div class="chat-txt">
                    <input type="text" class="form-control">
                </div>
                <!--<div class="btn-group hidden-sm hidden-xs">
                        <button type="button" class="btn btn-white"><i class="fa fa-meh-o"></i></button>
                        <button type="button" class="btn btn-white"><i class=" fa fa-paperclip"></i></button>
                    </div> -->
                <button class="btn btn-theme">Send</button>
            </form>
        </footer>

</div>