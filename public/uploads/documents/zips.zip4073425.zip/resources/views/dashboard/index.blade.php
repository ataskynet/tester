@extends('inspina')

@section('content')
    <!-- Dashboard or home view: List of Schools, Number of clients signed on, ... -->
    <h2>Dashboard: Owner</h2>

    <!-- End of the Dashboard section -->
    <!-- Partials directory: school.account.partials -->
@stop

