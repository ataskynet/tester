<p class="menu-title">BROWSE <span class="pull-right"><a href="javascript:;"><i></i></a></span></p>
<ul>
    <li class="start active "> <a href="{{ url('/'.$school->username.'/admin/') }}"> <i class="icon-custom-home"></i> <span class="title">Dashboard</span> <span class="selected"></span> </a> </li>

    <li class=""> <a href="{{ url('/'.$school->username.'/admin/mail/') }}"> <i class="icon-custom-ui"></i> <span class="title">Mail</span><span class=" badge badge-disable pull-right ">203</span></a>

    <li class=""> <a href="javascript:;"> <i class="icon-custom-form"></i> <span class="title">Forums</span> </span> <span class="badge badge-primary pull-right">5</span> </a>
        <ul class="sub-menu">
            <li > <a href=""> School Forum</a> </li>
            <li > <a href=""> Class Forum </a> </li>
        </ul>
    </li>
    <li class=""> <a href="javascript:;"> <i class="icon-custom-portlets"></i> <span class="title">Notifications</span> <span class="badge badge-important pull-right">5</span> </a> </li>
    <li class=""> <a href="javascript:;"> <i class="icon-custom-thumb"></i> <span class="title">Calendar</span></a>
        <ul class="sub-menu">
            <li > <a href=""> School Calendar</a> </li>
            <li > <a href=""> Intergrated Calendar </a> </li>
        </ul>
    </li>
    <li class=""> <a href="javascript:;"> <i class="icon-custom-map"></i> <span class="title">Contacts</span></a>

    </li>

    <li class="hidden-lg hidden-md hidden-xs" id="more-widgets" > <a href="javascript:;"> <i class="fa fa-plus"></i></a>
        <p class="menu-title">PROJECTS </p>
        <div class="status-widget">
            <div class="status-widget-wrapper">
                <div class="title">Freelancer<a href="#" class="remove-widget"><i class="icon-custom-cross"></i></a></div>
                <p>Redesign home page</p>
            </div>
        </div>
        <div class="status-widget">
            <div class="status-widget-wrapper">
                <div class="title">envato<a href="#" class="remove-widget"><i class="icon-custom-cross"></i></a></div>
                <p>Statistical report</p>
            </div>
        </div>
    </li>
</ul>
<div class="side-bar-widgets">
    <p class="menu-title">PROJECTS </p>
    <div class="status-widget">
        <div class="status-widget-wrapper">
            <div class="title"><a href="">New DoormRooms</a><a href="#" class="remove-widget"><i class="icon-custom-cross"></i></a></div>
            <p>Build New Spacious Doorm Rooms</p>
        </div>
    </div>
    <div class="status-widget">
        <div class="status-widget-wrapper">
            <div class="title"><a href="">envato</a><a href="#" class="remove-widget"><i class="icon-custom-cross"></i></a></div>
            <p>Statistical report</p>
        </div>
    </div>
</div>
<div class="clearfix"></div>