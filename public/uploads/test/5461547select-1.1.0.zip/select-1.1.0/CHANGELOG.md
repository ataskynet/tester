## v1.0.0
- Bump `Tether` to v1

## v1.0.0
- Add proper UMD to `Select`
- Convert from `Coffeescript` to `ES6 (Babel)`
- Fix `*.json` files to include `main`
- Remove bundled `select.js`
- Restructure directory layout
- Update `gulp` builds
- Update `tether` dependency to `v0.7.2`
